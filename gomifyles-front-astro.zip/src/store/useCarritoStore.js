import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useCarritoStore = create(
  persist(
    (set, get) => ({
      items: [], // cada item: { producto, cantidad }

      agregarProducto: (producto, cantidad = 1) => {
        const items = get().items
        const yaExiste = items.find((item) => item.producto.id === producto.id)

        if (yaExiste) {
          set({
            items: items.map((item) =>
              item.producto.id === producto.id
                ? { ...item, cantidad: item.cantidad + cantidad }
                : item,
            ),
          })
        } else {
          set({ items: [...items, { producto, cantidad }] })
        }
      },

      quitarProducto: (productoId) => {
        set({ items: get().items.filter((item) => item.producto.id !== productoId) })
      },

      vaciarCarrito: () => set({ items: [] }),

      total: () => {
        return get().items.reduce(
          (suma, item) => suma + item.producto.precio * item.cantidad,
          0,
        )
      },
    }),
    { name: 'ecommerce-carrito' },
  ),
)
