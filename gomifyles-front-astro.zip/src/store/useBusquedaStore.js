import { create } from 'zustand'

export const useBusquedaStore = create((set) => ({
  texto: '',
  setTexto: (texto) => set({ texto }),
}))
