import { useEffect, useMemo, useState, useTransition } from 'react'
import { useConsulta } from '../hooks/useConsulta'
import { useBusquedaStore } from '../store/useBusquedaStore'
import { useCarritoStore } from '../store/useCarritoStore'
import { ProductoCard } from '../components/ProductoCard'
import { SkeletonGrid } from '../components/Skeleton'
import { Modal } from '../components/Modal'
import { DetalleProducto } from '../components/DetalleProducto'
import { Sidebar } from '../components/Sidebar'

const QUERY_HOME = `
  {
    categorias { id nombre }
    productos {
      id
      nombre
      imagen
      precio
      disponibilidad
      categoria { id nombre }
    }
  }
`

export function CatalogoIsland() {
  const { datos, cargando, error } = useConsulta(QUERY_HOME, {}, [])
  const busqueda = useBusquedaStore((state) => state.texto)
  const agregarProducto = useCarritoStore((state) => state.agregarProducto)
  const [isPending, startTransition] = useTransition()

  const [productoSeleccionado, setProductoSeleccionado] = useState(null)
  const [textoFiltrado, setTextoFiltrado] = useState(busqueda)

  useEffect(() => {
    startTransition(() => { setTextoFiltrado(busqueda) })
  }, [busqueda])

  const productosFiltrados = useMemo(() => {
    if (!datos) return []
    const texto = textoFiltrado.toLowerCase()
    return datos.productos.filter((p) => p.nombre.toLowerCase().includes(texto))
  }, [datos, textoFiltrado])

  if (error) return <p style={{ color: 'var(--color-danger)' }}>Error al cargar el catálogo: {error}</p>

  return (
    <div className="flex flex-col md:flex-row gap-8">
      {!cargando && <Sidebar categorias={datos.categorias} />}

      <main className="flex-1">
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {cargando ? (
            <SkeletonGrid cantidad={6} />
          ) : (
            productosFiltrados.map((producto) => (
              <ProductoCard key={producto.id} producto={producto} onSeleccionar={setProductoSeleccionado} />
            ))
          )}
        </div>

        {!cargando && productosFiltrados.length === 0 && (
          <p className="mt-6" style={{ color: 'var(--color-ink-muted)' }}>
            No se encontraron productos con ese nombre.
          </p>
        )}

        {isPending && (
          <p className="text-xs mt-3" style={{ color: 'var(--color-ink-muted)' }}>Filtrando...</p>
        )}
      </main>

      <Modal open={!!productoSeleccionado} onClose={() => setProductoSeleccionado(null)} title="Detalle del producto">
        {productoSeleccionado && (
          <DetalleProducto
            productoId={productoSeleccionado.id}
            onAgregarAlCarrito={(producto, cantidad) => {
              agregarProducto(producto, cantidad)
              setProductoSeleccionado(null)
            }}
          />
        )}
      </Modal>
    </div>
  )
}
