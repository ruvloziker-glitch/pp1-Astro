import { useCarritoStore } from '../store/useCarritoStore'

export function CarritoIsland() {
  const items = useCarritoStore((state) => state.items)
  const quitarProducto = useCarritoStore((state) => state.quitarProducto)
  const total = useCarritoStore((state) => state.total())

  if (items.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <p className="mb-4" style={{ color: 'var(--color-ink-muted)' }}>Tu carrito está vacío.</p>
        <a href="/catalogo" className="hover:underline" style={{ color: 'var(--color-primary)' }}>
          Ir al catálogo
        </a>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-10">
      <h2 className="text-2xl mb-6" style={{ color: 'var(--color-ink)' }}>Tu carrito</h2>

      <div className="flex flex-col gap-3 mb-6">
        {items.map((item) => (
          <div key={item.producto.id} className="flex items-center gap-4 rounded-md border p-3" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)' }}>
            <img src={item.producto.imagen} alt="" className="h-16 w-16 object-cover rounded" />
            <div className="flex-1">
              <p className="font-medium" style={{ color: 'var(--color-ink)' }}>{item.producto.nombre}</p>
              <p className="text-sm" style={{ color: 'var(--color-ink-muted)' }}>{item.cantidad} × ${item.producto.precio}</p>
            </div>
            <button type="button" onClick={() => quitarProducto(item.producto.id)} className="text-xs cursor-pointer hover:underline" style={{ color: 'var(--color-danger)' }}>
              Quitar
            </button>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between border-t pt-4" style={{ borderColor: 'var(--color-border)' }}>
        <p className="text-lg font-semibold" style={{ color: 'var(--color-ink)' }}>Total: ${total.toFixed(2)}</p>
        <a href="/checkout" className="rounded px-5 py-2 font-medium" style={{ background: 'var(--color-primary)', color: 'var(--color-primary-ink)' }}>
          Ir a pagar
        </a>
      </div>
    </div>
  )
}
