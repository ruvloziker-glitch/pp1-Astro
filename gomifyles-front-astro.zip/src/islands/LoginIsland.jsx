import { useState } from 'react'
import { consultarGraphQL } from '../lib/graphql'

const MUTATION_SOLICITAR = `
  mutation ($correo: String!) {
    solicitarCodigo(correo: $correo)
  }
`

const MUTATION_VERIFICAR = `
  mutation ($correo: String!, $codigo: String!) {
    verificarCodigo(correo: $correo, codigo: $codigo) {
      id
      correo
    }
  }
`

export function LoginIsland() {
  const [paso, setPaso] = useState('correo') // 'correo' | 'codigo'
  const [correo, setCorreo] = useState('')
  const [codigo, setCodigo] = useState('')
  const [codigoDemo, setCodigoDemo] = useState(null)
  const [enviando, setEnviando] = useState(false)
  const [error, setError] = useState(null)

  async function pedirCodigo(evento) {
    evento.preventDefault()
    setEnviando(true)
    setError(null)
    try {
      const resultado = await consultarGraphQL(MUTATION_SOLICITAR, { correo })
      setCodigoDemo(resultado.solicitarCodigo)
      setPaso('codigo')
    } catch (err) {
      setError(err.message)
    } finally {
      setEnviando(false)
    }
  }

  async function confirmarCodigo(evento) {
    evento.preventDefault()
    setEnviando(true)
    setError(null)
    try {
      await consultarGraphQL(MUTATION_VERIFICAR, { correo, codigo })
      window.location.href = '/catalogo'
    } catch (err) {
      setError(err.message)
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="max-w-sm mx-auto px-4 py-16">
      <h2 className="text-2xl mb-2" style={{ color: 'var(--color-ink)' }}>Iniciar sesión</h2>
      <p className="text-sm mb-6" style={{ color: 'var(--color-ink-muted)' }}>
        Sin contraseña: te mandamos un código de un solo uso.
      </p>

      {paso === 'correo' && (
        <form onSubmit={pedirCodigo} className="flex flex-col gap-4">
          <input
            type="email"
            required
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
            placeholder="tu@correo.com"
            className="rounded-md px-3 py-2 text-sm border"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-ink)' }}
          />

          {error && <p className="text-sm" style={{ color: 'var(--color-danger)' }}>{error}</p>}

          <button
            type="submit"
            disabled={enviando}
            className="rounded py-2 font-medium cursor-pointer disabled:opacity-50"
            style={{ background: 'var(--color-primary)', color: 'var(--color-primary-ink)' }}
          >
            {enviando ? 'Enviando...' : 'Enviar código'}
          </button>
        </form>
      )}

      {paso === 'codigo' && (
        <form onSubmit={confirmarCodigo} className="flex flex-col gap-4">
          <div className="rounded-md border p-3 text-sm" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-ink)' }}>
            No hay servicio de correo configurado, así que aquí está tu código
            (en un correo real esto llegaría a tu bandeja de entrada):
            <p className="text-lg font-semibold mt-1 tracking-widest">{codigoDemo}</p>
          </div>

          <input
            type="text"
            required
            inputMode="numeric"
            maxLength={6}
            value={codigo}
            onChange={(e) => setCodigo(e.target.value)}
            placeholder="Código de 6 dígitos"
            className="rounded-md px-3 py-2 text-sm border tracking-widest"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-ink)' }}
          />

          {error && <p className="text-sm" style={{ color: 'var(--color-danger)' }}>{error}</p>}

          <button
            type="submit"
            disabled={enviando}
            className="rounded py-2 font-medium cursor-pointer disabled:opacity-50"
            style={{ background: 'var(--color-primary)', color: 'var(--color-primary-ink)' }}
          >
            {enviando ? 'Verificando...' : 'Entrar'}
          </button>

          <button
            type="button"
            onClick={() => { setPaso('correo'); setCodigo(''); setError(null) }}
            className="text-sm cursor-pointer hover:underline"
            style={{ color: 'var(--color-ink-muted)' }}
          >
            ← Usar otro correo
          </button>
        </form>
      )}
    </div>
  )
}
