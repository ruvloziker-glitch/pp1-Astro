import { useState } from 'react'
import { consultarGraphQL } from '../lib/graphql'
import { useCarritoStore } from '../store/useCarritoStore'
import { obtenerSesionId } from '../lib/sesion'

const MUTATION_CREAR_PEDIDO = `
  mutation ($sesionId: String!, $items: [ItemPedidoInput!]!) {
    crearPedido(sesionId: $sesionId, items: $items) {
      id
      total
      fecha
    }
  }
`

export function CheckoutIsland() {
  const items = useCarritoStore((state) => state.items)
  const total = useCarritoStore((state) => state.total())
  const vaciarCarrito = useCarritoStore((state) => state.vaciarCarrito)

  const [enviando, setEnviando] = useState(false)
  const [error, setError] = useState(null)
  const [pedidoConfirmado, setPedidoConfirmado] = useState(null)

  async function confirmarPedido(evento) {
    evento.preventDefault()
    setEnviando(true)
    setError(null)

    try {
      const itemsParaBackend = items.map((item) => ({
        productoId: item.producto.id,
        cantidad: item.cantidad,
      }))

      const sesionId = obtenerSesionId()
      const resultado = await consultarGraphQL(MUTATION_CREAR_PEDIDO, { sesionId, items: itemsParaBackend })
      setPedidoConfirmado(resultado.crearPedido)
      vaciarCarrito()
    } catch (err) {
      setError(err.message)
    } finally {
      setEnviando(false)
    }
  }

  if (pedidoConfirmado) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <p className="text-lg font-semibold mb-2" style={{ color: 'var(--color-primary)' }}>Pedido confirmado</p>
        <p className="mb-6" style={{ color: 'var(--color-ink-muted)' }}>
          Pedido #{pedidoConfirmado.id} · Total ${pedidoConfirmado.total}
        </p>
        <a href="/catalogo" className="hover:underline" style={{ color: 'var(--color-primary)' }}>
          Volver al catálogo
        </a>
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <p className="mb-4" style={{ color: 'var(--color-ink-muted)' }}>No tienes productos en el carrito.</p>
        <a href="/catalogo" className="hover:underline" style={{ color: 'var(--color-primary)' }}>
          Ir al catálogo
        </a>
      </div>
    )
  }

  return (
    <div className="max-w-md mx-auto px-4 py-10">
      <h2 className="text-2xl mb-6" style={{ color: 'var(--color-ink)' }}>Confirmar compra</h2>

      <form onSubmit={confirmarPedido} className="flex flex-col gap-4">
        <div className="rounded-md border p-4" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)' }}>
          <p className="text-sm mb-2" style={{ color: 'var(--color-ink-muted)' }}>{items.length} producto(s) en el pedido</p>
          <p className="text-lg font-semibold" style={{ color: 'var(--color-ink)' }}>Total: ${total.toFixed(2)}</p>
        </div>

        {error && <p className="text-sm" style={{ color: 'var(--color-danger)' }}>{error}</p>}

        <button type="submit" disabled={enviando} className="rounded py-2 font-medium cursor-pointer disabled:opacity-50" style={{ background: 'var(--color-primary)', color: 'var(--color-primary-ink)' }}>
          {enviando ? 'Enviando...' : 'Confirmar pedido'}
        </button>

        <a href="/carrito" className="text-sm text-center hover:underline" style={{ color: 'var(--color-ink-muted)' }}>
          ← Volver al carrito
        </a>
      </form>
    </div>
  )
}
