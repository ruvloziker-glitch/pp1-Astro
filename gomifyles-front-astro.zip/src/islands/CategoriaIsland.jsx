import { useEffect, useState } from 'react'
import { useConsulta } from '../hooks/useConsulta'
import { useCarritoStore } from '../store/useCarritoStore'
import { ProductoCard } from '../components/ProductoCard'
import { SkeletonGrid } from '../components/Skeleton'
import { Modal } from '../components/Modal'
import { DetalleProducto } from '../components/DetalleProducto'

const QUERY_POR_CATEGORIA = `
  query ($categoriaId: ID!) {
    categoria(id: $categoriaId) { id nombre descripcion imagen }
    productos(categoriaId: $categoriaId) {
      id
      nombre
      imagen
      precio
      disponibilidad
    }
  }
`

export function CategoriaIsland() {
  const [categoriaId, setCategoriaId] = useState(null)

  useEffect(() => {
    const parametros = new URLSearchParams(window.location.search)
    setCategoriaId(parametros.get('id'))
  }, [])

  const { datos, cargando, error } = useConsulta(
    QUERY_POR_CATEGORIA,
    { categoriaId },
    [categoriaId],
  )
  const agregarProducto = useCarritoStore((state) => state.agregarProducto)
  const [productoSeleccionado, setProductoSeleccionado] = useState(null)

  if (!categoriaId) return null
  if (error) return <p style={{ color: 'var(--color-danger)' }}>Error: {error}</p>

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <a
        href="/catalogo"
        className="inline-block text-sm mb-6 underline-offset-4 hover:underline"
        style={{ color: 'var(--color-ink-muted)' }}
      >
        ← Volver al catálogo
      </a>

      {!cargando && datos.categoria.imagen && (
        <img
          src={datos.categoria.imagen}
          alt={datos.categoria.nombre}
          className="w-full h-40 object-cover rounded-md mb-4"
        />
      )}
      {!cargando && (
        <h2 className="text-2xl mb-1" style={{ color: 'var(--color-ink)' }}>{datos.categoria.nombre}</h2>
      )}
      {!cargando && datos.categoria.descripcion && (
        <p className="mb-6" style={{ color: 'var(--color-ink-muted)' }}>{datos.categoria.descripcion}</p>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {cargando ? (
          <SkeletonGrid cantidad={6} />
        ) : (
          datos.productos.map((producto) => (
            <ProductoCard key={producto.id} producto={producto} onSeleccionar={setProductoSeleccionado} />
          ))
        )}
      </div>

      <Modal open={!!productoSeleccionado} onClose={() => setProductoSeleccionado(null)} title="Detalle del producto">
        {productoSeleccionado && (
          <DetalleProducto
            productoId={productoSeleccionado.id}
            onAgregarAlCarrito={(producto, cantidad) => {
              agregarProducto(producto, cantidad)
              setProductoSeleccionado(null)
            }}
          />
        )}
      </Modal>
    </div>
  )
}
