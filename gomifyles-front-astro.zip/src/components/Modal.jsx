import { useEffect } from 'react'
import { createPortal } from 'react-dom'

export function Modal({ open, onClose, title, children }) {
  useEffect(() => {
    if (!open) return

    const cerrarConEsc = (e) => { if (e.key === 'Escape') onClose?.() }
    document.addEventListener('keydown', cerrarConEsc)

    const overflowPrevio = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    return () => {
      document.removeEventListener('keydown', cerrarConEsc)
      document.body.style.overflow = overflowPrevio
    }
  }, [open, onClose])

  if (!open) return null

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0" style={{ background: 'rgba(62,58,46,0.45)' }} aria-hidden />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg rounded-md border p-6 shadow-sm"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-serif text-lg" style={{ color: 'var(--color-ink)' }}>{title}</h3>
          <button
            onClick={onClose}
            aria-label="Cerrar"
            className="rounded border px-3 py-1 text-xs cursor-pointer"
            style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-muted)' }}
          >
            Cerrar
          </button>
        </div>
        {children}
      </div>
    </div>,
    document.body,
  )
}
