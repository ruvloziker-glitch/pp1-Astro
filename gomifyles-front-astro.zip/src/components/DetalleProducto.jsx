import { useState } from 'react'
import { useConsulta } from '../hooks/useConsulta'

const QUERY_PRODUCTO = `
  query ($id: ID!) {
    producto(id: $id) {
      id
      nombre
      imagen
      precio
      sabores
      disponibilidad
      categoria { nombre }
    }
  }
`

export function DetalleProducto({ productoId, onAgregarAlCarrito }) {
  const [cantidad, setCantidad] = useState(1)
  const { datos, cargando, error } = useConsulta(QUERY_PRODUCTO, { id: productoId }, [productoId])

  if (cargando) return <p style={{ color: 'var(--color-ink-muted)' }}>Cargando producto...</p>
  if (error) return <p style={{ color: 'var(--color-danger)' }}>Error: {error}</p>

  const producto = datos.producto
  const agotado = producto.disponibilidad <= 0

  return (
    <div>
      <img src={producto.imagen} alt={producto.nombre} className="h-48 w-full object-cover rounded mb-4" />
      <p className="text-sm mb-1" style={{ color: 'var(--color-ink-muted)' }}>{producto.categoria.nombre}</p>
      <h4 className="text-xl font-serif mb-2" style={{ color: 'var(--color-ink)' }}>{producto.nombre}</h4>
      <p className="text-lg font-semibold mb-2" style={{ color: 'var(--color-accent)' }}>${producto.precio}</p>

      {producto.sabores?.length > 0 && (
        <p className="text-sm mb-2" style={{ color: 'var(--color-ink-muted)' }}>
          Sabores: {producto.sabores.join(', ')}
        </p>
      )}

      <p className="text-sm mb-4">
        {agotado ? (
          <span style={{ color: 'var(--color-danger)' }}>Agotado</span>
        ) : (
          <span style={{ color: 'var(--color-ink-muted)' }}>{producto.disponibilidad} disponibles</span>
        )}
      </p>

      {!agotado && (
        <div className="flex items-center gap-3">
          <input
            type="number"
            min="1"
            max={producto.disponibilidad}
            value={cantidad}
            onChange={(e) => setCantidad(Number(e.target.value))}
            className="w-20 rounded px-2 py-1 text-sm border"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg)' }}
          />
          <button
            type="button"
            onClick={() => onAgregarAlCarrito(producto, cantidad)}
            className="flex-1 rounded py-2 font-medium cursor-pointer"
            style={{ background: 'var(--color-primary)', color: 'var(--color-primary-ink)' }}
          >
            Agregar al carrito
          </button>
        </div>
      )}
    </div>
  )
}
