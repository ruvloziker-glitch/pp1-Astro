export function Sidebar({ categorias, categoriaActivaId = null }) {
  return (
    <aside className="w-full md:w-52 shrink-0">
      <h3 className="text-sm mb-3" style={{ color: 'var(--color-ink-muted)' }}>
        Categorías
      </h3>
      <ul className="flex md:flex-col gap-1 overflow-x-auto md:overflow-visible">
        {categorias.map((categoria) => {
          const activa = String(categoria.id) === String(categoriaActivaId)
          return (
            <li key={categoria.id}>
              <a
                href={`/categoria?id=${categoria.id}`}
                className="block whitespace-nowrap w-full text-left px-3 py-2 text-sm border-l-2 transition-colors"
                style={{
                  borderColor: activa ? 'var(--color-primary)' : 'transparent',
                  color: activa ? 'var(--color-ink)' : 'var(--color-ink-muted)',
                  background: activa ? 'var(--color-surface)' : 'transparent',
                }}
              >
                {categoria.nombre}
              </a>
            </li>
          )
        })}
      </ul>
    </aside>
  )
}
