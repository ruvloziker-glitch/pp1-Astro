import { useCarritoStore } from '../store/useCarritoStore'
import { useBusquedaStore } from '../store/useBusquedaStore'
import { useConsulta } from '../hooks/useConsulta'
import { consultarGraphQL } from '../lib/graphql'

const QUERY_YO = `{ yo { id correo } }`
const MUTATION_CERRAR_SESION = `mutation { cerrarSesion }`

export function TopBar() {
  const items = useCarritoStore((state) => state.items)
  const cantidadCarrito = items.reduce((suma, item) => suma + item.cantidad, 0)

  const busqueda = useBusquedaStore((state) => state.texto)
  const setBusqueda = useBusquedaStore((state) => state.setTexto)

  const { datos } = useConsulta(QUERY_YO, {}, [])
  const usuario = datos?.yo

  function buscarYEntrar(e) {
    e.preventDefault()
    if (window.location.pathname !== '/catalogo') {
      window.location.href = '/catalogo'
    }
  }

  async function cerrarSesion() {
    await consultarGraphQL(MUTATION_CERRAR_SESION)
    window.location.href = '/catalogo'
  }

  return (
    <header
      className="sticky top-0 z-20 border-b"
      style={{ background: 'var(--color-bg)', borderColor: 'var(--color-border)' }}
    >
      <div className="max-w-5xl mx-auto flex items-center gap-4 px-4 py-4">
        <a href="/catalogo" className="text-left">
          <span className="font-serif text-lg" style={{ color: 'var(--color-ink)' }}>
            GomiFyles
          </span>
          <span className="regla-firma" />
        </a>

        <form onSubmit={buscarYEntrar} className="flex-1">
          <input
            type="text"
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Buscar por nombre de producto..."
            className="w-full rounded-md px-3 py-2 text-sm border focus:outline-none"
            style={{
              background: 'var(--color-surface)',
              borderColor: 'var(--color-border)',
              color: 'var(--color-ink)',
            }}
          />
        </form>

        {usuario ? (
          <div className="flex items-center gap-2 text-sm">
            <span className="hidden sm:inline" style={{ color: 'var(--color-ink-muted)' }}>{usuario.correo}</span>
            <button
              type="button"
              onClick={cerrarSesion}
              className="rounded-md px-3 py-2 border cursor-pointer"
              style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink)' }}
            >
              Cerrar sesión
            </button>
          </div>
        ) : (
          <a
            href="/login"
            className="rounded-md px-3 py-2 text-sm border"
            style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink)' }}
          >
            Iniciar sesión
          </a>
        )}

        <a
          href="/carrito"
          className="relative rounded-md px-3 py-2 text-sm border"
          style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink)' }}
        >
          Carrito
          {cantidadCarrito > 0 && (
            <span
              className="absolute -top-2 -right-2 text-xs rounded-full w-5 h-5 flex items-center justify-center font-medium"
              style={{ background: 'var(--color-primary)', color: 'var(--color-primary-ink)' }}
            >
              {cantidadCarrito}
            </span>
          )}
        </a>
      </div>
    </header>
  )
}
