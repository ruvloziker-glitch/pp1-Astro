export function SkeletonCard() {
  return (
    <div
      className="rounded-md border p-4 animate-pulse"
      style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)' }}
    >
      <div className="h-32 rounded mb-3" style={{ background: 'var(--color-border)' }} />
      <div className="h-4 w-3/4 rounded mb-2" style={{ background: 'var(--color-border)' }} />
      <div className="h-4 w-1/2 rounded" style={{ background: 'var(--color-border)' }} />
    </div>
  )
}

export function SkeletonGrid({ cantidad = 6 }) {
  return (
    <>
      {Array.from({ length: cantidad }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </>
  )
}
