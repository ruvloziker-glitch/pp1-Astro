Terminal 1 en el backend:
cd back
npm install
npm run start

http://localhost:3000/graphql

Terminal 2 en el frontend:
cd front-astro
npm install
npm run dev

http://localhost:4321

## Variables de entorno del backend

El backend ahora lee la conexión a la base de datos desde un .env
(back/.env) en vez de tenerla escrita en app.module.ts. El .env ya
viene con tus datos de Neon, no hay que tocar nada — pero ya no se
sube a GitHub (está en .gitignore), que era el problema de seguridad
que te comenté antes.

## Qué cambió respecto al front en Vite+React

- Cada vista ahora es una página real con su propia URL:
  /, /catalogo, /categoria?id=N, /carrito, /checkout, /login
- Hero y Footer son componentes .astro estáticos, sin JavaScript.
- El resto (Sidebar, grid de productos, modal, carrito, checkout,
  login) sigue siendo React, pero ahora como "islas" (client:load)
  dentro de cada página en vez de una sola app gigante.
- El id de sesión del carrito ya no vive en un Context de React (se
  perdía al navegar entre páginas); ahora se guarda en localStorage
  (src/lib/sesion.js).
- Todo el fetch a GraphQL sigue siendo del lado del cliente, igual
  que antes — por eso /categoria usa un query param (?id=) en vez de
  una ruta dinámica de Astro: el backend solo existe en localhost,
  así que no hay forma de resolverlo en build ni en servidor, tiene
  que resolverse en el navegador de quien lo esté viendo.

## Auth: código de un solo uso (sin contraseña)

- /login pide tu correo, el backend genera un código de 6 dígitos
  (válido 10 minutos) y lo guarda en la tabla usuario.
- Como no hay servicio de correo configurado, el código se muestra
  directo en pantalla simulando que "llegó" — eso se reemplazaría
  por un envío real de correo en un proyecto en producción.
- Al capturar el código correcto, el backend crea una sesión (tabla
  sesion) y manda una cookie httpOnly con el token. Esa cookie dura
  7 días.
- El TopBar consulta `yo` en cada página para saber si hay sesión
  activa y mostrar el correo o el botón de "Iniciar sesión".
- El checkout NO exige sesión — sigue funcionando como invitado,
  igual que en el proyecto original. El login es una capa aparte,
  no un bloqueo.
