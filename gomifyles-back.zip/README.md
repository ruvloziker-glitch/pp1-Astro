Node.js instalado
Una base de PostgreSQL (local o en la nube)

Como correrlo
1. Instala las dependencias:
npm install

2. La conexión a la base de datos ya viene lista en el archivo .env
   (tus datos de Neon). Si algún día cambias de base, solo edita ese
   .env — no hay nada escrito a mano en el código. .env no se sube a
   GitHub (está en .gitignore); si clonas el repo en otra máquina,
   copia .env.example a .env y pon ahí tus propios datos.

3. Levanta el servidor:
   npm run start

4. Abre `http://localhost:3000/graphql` para probar queries y mutations
   sin necesidad del frontend.

## Cómo está organizado

Un módulo por entidad: `categoria/`, `producto/`, `pedido/`, `detalle-pedido/`,
`usuario/`. Cada uno tiene: `*.entity.ts` (type de GraphQL + tabla), `*.service.ts`
(lógica), `*.resolver.ts` (queries/mutations). `producto/producto.input.ts` trae
los inputs para crear/actualizar producto.

`usuario/` trae además `sesion.entity.ts`: cada login real crea una fila ahí con
el token que se manda como cookie httpOnly.

## Auth: código de un solo uso

Sin contraseña. El flujo es:

```graphql
mutation { solicitarCodigo(correo: "tu@correo.com") }
```
Regresa el código de 6 dígitos directo (no hay servicio de correo real
configurado, así que no llega a ningún lado — se regresa aquí mismo para
poder probarlo).

```graphql
mutation {
  verificarCodigo(correo: "tu@correo.com", codigo: "123456") {
    id
    correo
  }
}
```
Si el código es correcto y no venció (10 minutos), crea la sesión y manda
la cookie. Desde el Playground no vas a ver la cookie aplicarse igual que
en el navegador, pero sí puedes confirmar que no truena.

```graphql
{ yo { id correo } }
```
Con la cookie puesta, regresa el usuario de la sesión actual; sin cookie,
regresa `null`.

```graphql
mutation { cerrarSesion }
```
Borra la sesión y limpia la cookie.

## Ejemplos para el Playground

Catálogo con categoría:
```graphql
{
  productos {
    id
    nombre
    precio
    disponibilidad
    categoria { nombre }
  }
}
```

Detalle de un producto:
```graphql
{
  producto(id: 1) {
    nombre
    precio
    sabores
    disponibilidad
  }
}
```

CRUD de producto:
```graphql
mutation {
  crearProducto(input: {
    nombre: "Paletas de gomita"
    precio: 25
    disponibilidad: 30
    categoriaId: 2
  }) { id nombre }
}

mutation {
  actualizarProducto(input: { id: 1, precio: 49.00 }) { id nombre precio }
}

mutation {
  eliminarProducto(id: 1)
}
```

Registrar un pedido (checkout) — comprando aros ácidos y ositos clásicos:
```graphql
mutation {
  crearPedido(
    sesionId: "sesion-demo-1"
    items: [
      { productoId: 1, cantidad: 2 }
      { productoId: 2, cantidad: 1 }
    ]
  ) {
    id
    total
    detalles {
      cantidad
      producto { nombre }
    }
  }
}
```
