import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { Pedido } from './pedido.entity';
import { PedidoService } from './pedido.service';
import { ItemPedidoInput } from './item-pedido.input';

@Resolver(() => Pedido)
export class PedidoResolver {
  constructor(private pedidoService: PedidoService) {}

  @Mutation(() => Pedido)
  crearPedido(
    @Args('sesionId') sesionId: string,
    @Args({ name: 'items', type: () => [ItemPedidoInput] }) items: ItemPedidoInput[],
  ): Promise<Pedido> {
    return this.pedidoService.crearPedido(sesionId, items);
  }

  @Query(() => [Pedido])
  pedidosPorSesion(@Args('sesionId') sesionId: string): Promise<Pedido[]> {
    return this.pedidoService.encontrarPorSesion(sesionId);
  }
}
