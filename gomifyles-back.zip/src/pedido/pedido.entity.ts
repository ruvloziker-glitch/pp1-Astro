import { ObjectType, Field, ID, Float } from '@nestjs/graphql';
import { Entity, PrimaryGeneratedColumn, Column, OneToMany, CreateDateColumn } from 'typeorm';
import { DetallePedido } from '../detalle-pedido/detalle-pedido.entity';

@ObjectType()
@Entity()
export class Pedido {
  @Field(() => ID)
  @PrimaryGeneratedColumn()
  id: number;

  @Field()
  @Column()
  sesionId: string;

  @Field()
  @CreateDateColumn()
  fecha: Date;

  @Field(() => Float)
  @Column('real')
  total: number;

  @Field(() => [DetallePedido])
  @OneToMany(() => DetallePedido, (detalle) => detalle.pedido, { cascade: true })
  detalles: DetallePedido[];
}
