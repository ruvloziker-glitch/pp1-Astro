import { Injectable, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { randomBytes, randomInt } from 'crypto';
import { Usuario } from './usuario.entity';
import { Sesion } from './sesion.entity';

const MINUTOS_VIGENCIA_CODIGO = 10;
const DIAS_VIGENCIA_SESION = 7;

@Injectable()
export class UsuarioService {
  constructor(
    @InjectRepository(Usuario) private usuarioRepo: Repository<Usuario>,
    @InjectRepository(Sesion) private sesionRepo: Repository<Sesion>,
  ) {}

  async solicitarCodigo(correo: string): Promise<string> {
    let usuario = await this.usuarioRepo.findOne({ where: { correo } });
    if (!usuario) {
      usuario = this.usuarioRepo.create({ correo });
    }

    const codigo = randomInt(100000, 999999).toString();
    usuario.codigoActual = codigo;
    usuario.codigoExpira = new Date(Date.now() + MINUTOS_VIGENCIA_CODIGO * 60 * 1000);
    await this.usuarioRepo.save(usuario);

    // No hay servicio de correo configurado: el código se regresa aquí mismo
    // para mostrarlo en pantalla, simulando el "correo" que le llegaría.
    return codigo;
  }

  async verificarCodigo(correo: string, codigo: string): Promise<string> {
    const usuario = await this.usuarioRepo.findOne({ where: { correo } });

    if (
      !usuario ||
      !usuario.codigoActual ||
      usuario.codigoActual !== codigo ||
      !usuario.codigoExpira ||
      usuario.codigoExpira.getTime() < Date.now()
    ) {
      throw new UnauthorizedException('Código inválido o vencido');
    }

    usuario.codigoActual = null;
    usuario.codigoExpira = null;
    await this.usuarioRepo.save(usuario);

    const token = randomBytes(32).toString('hex');
    const sesion = this.sesionRepo.create({
      token,
      usuario,
      expira: new Date(Date.now() + DIAS_VIGENCIA_SESION * 24 * 60 * 60 * 1000),
    });
    await this.sesionRepo.save(sesion);

    return token;
  }

  async obtenerUsuarioPorToken(token: string | undefined): Promise<Usuario | null> {
    if (!token) return null;

    const sesion = await this.sesionRepo.findOne({
      where: { token },
      relations: ['usuario'],
    });

    if (!sesion || sesion.expira.getTime() < Date.now()) return null;

    return sesion.usuario;
  }

  async cerrarSesion(token: string | undefined): Promise<boolean> {
    if (!token) return false;
    await this.sesionRepo.delete({ token });
    return true;
  }
}
