import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Usuario } from './usuario.entity';
import { Sesion } from './sesion.entity';
import { UsuarioService } from './usuario.service';
import { UsuarioResolver } from './usuario.resolver';

@Module({
  imports: [TypeOrmModule.forFeature([Usuario, Sesion])],
  providers: [UsuarioService, UsuarioResolver],
  exports: [UsuarioService],
})
export class UsuarioModule {}
