import { ObjectType, Field, ID } from '@nestjs/graphql';
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@ObjectType()
@Entity('usuario_auth')
export class Usuario {
  @Field(() => ID)
  @PrimaryGeneratedColumn()
  id: number;

  @Field()
  @Column({ unique: true })
  correo: string;

  // No se expone en GraphQL (sin @Field): solo el backend los usa para validar.
  @Column({ nullable: true })
  codigoActual: string;

  @Column({ type: 'timestamp', nullable: true })
  codigoExpira: Date;
}
