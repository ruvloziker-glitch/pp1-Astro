import { Resolver, Query, Mutation, Args, Context } from '@nestjs/graphql';
import { Usuario } from './usuario.entity';
import { UsuarioService } from './usuario.service';

const NOMBRE_COOKIE = 'gomifyles_sesion';
const MILISEGUNDOS_SESION = 7 * 24 * 60 * 60 * 1000;

@Resolver(() => Usuario)
export class UsuarioResolver {
  constructor(private usuarioService: UsuarioService) {}

  @Mutation(() => String)
  solicitarCodigo(@Args('correo') correo: string): Promise<string> {
    return this.usuarioService.solicitarCodigo(correo);
  }

  @Mutation(() => Usuario)
  async verificarCodigo(
    @Args('correo') correo: string,
    @Args('codigo') codigo: string,
    @Context() context: any,
  ): Promise<Usuario> {
    const token = await this.usuarioService.verificarCodigo(correo, codigo);

    context.res.cookie(NOMBRE_COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: MILISEGUNDOS_SESION,
    });

    return this.usuarioService.obtenerUsuarioPorToken(token);
  }

  @Mutation(() => Boolean)
  async cerrarSesion(@Context() context: any): Promise<boolean> {
    const token = context.req.cookies?.[NOMBRE_COOKIE];
    context.res.clearCookie(NOMBRE_COOKIE);
    return this.usuarioService.cerrarSesion(token);
  }

  @Query(() => Usuario, { nullable: true })
  yo(@Context() context: any): Promise<Usuario | null> {
    const token = context.req.cookies?.[NOMBRE_COOKIE];
    return this.usuarioService.obtenerUsuarioPorToken(token);
  }
}
