import { Entity, PrimaryColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { Usuario } from './usuario.entity';

@Entity('sesion_auth')
export class Sesion {
  @PrimaryColumn()
  token: string;

  @ManyToOne(() => Usuario, { onDelete: 'CASCADE' })
  usuario: Usuario;

  @Column({ type: 'timestamp' })
  expira: Date;

  @CreateDateColumn()
  creada: Date;
}
