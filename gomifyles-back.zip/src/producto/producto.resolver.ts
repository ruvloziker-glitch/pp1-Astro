import { Resolver, Query, Mutation, Args, ID } from '@nestjs/graphql';
import { Producto } from './producto.entity';
import { ProductoService } from './producto.service';
import { CrearProductoInput, ActualizarProductoInput } from './producto.input';

@Resolver(() => Producto)
export class ProductoResolver {
  constructor(private productoService: ProductoService) {}

  @Query(() => [Producto])
  productos(
    @Args('categoriaId', { type: () => ID, nullable: true }) categoriaId?: number,
  ): Promise<Producto[]> {
    return this.productoService.encontrarTodos(categoriaId);
  }

  @Query(() => Producto, { nullable: true })
  producto(@Args('id', { type: () => ID }) id: number): Promise<Producto> {
    return this.productoService.encontrarUno(id);
  }

  @Mutation(() => Producto)
  crearProducto(@Args('input') input: CrearProductoInput): Promise<Producto> {
    return this.productoService.crearProducto(input);
  }

  @Mutation(() => Producto)
  actualizarProducto(@Args('input') input: ActualizarProductoInput): Promise<Producto> {
    return this.productoService.actualizarProducto(input);
  }

  @Mutation(() => Boolean)
  eliminarProducto(@Args('id', { type: () => ID }) id: number): Promise<boolean> {
    return this.productoService.eliminarProducto(id);
  }
}
